<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Site</title>
    <link rel="stylesheet" href="<?php bloginfo('template_directory')?>/css/style.css">
    <link rel="stylesheet" href="<?php bloginfo('template_directory')?>/css/reset.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;500;700&display=swap" rel="stylesheet">
    <title>EVEREST</title>
</head>
<body>

    <div class="main-menu">   
        <div class="menu-strip">
            <div class="toggle-btn">
                <span></span>
            </div>
        </div>
        <div class="nav">
            <div class="ul">
                <ul class="menu_menu">
                    <li class="elem">
                        <span id="oreder">01.</span>
                        <span id="menu">&nbsp;ABOUT US</span>
                    </li>
                    <li class="elem">
                        <span id="oreder">02.</span>
                        <span id="menu">&nbsp;ABOUT TRIP</span>
                    </li>
                    <li class="elem">
                        <span id="oreder">03.</span>
                        <span id="menu">&nbsp;EQUIPMENT REQUIRED</span>
                    </li>
                    <li class="elem">
                        <span id="oreder">04.</span>
                        <span id="menu">&nbsp;QUESTIONS</span>
                    </li>
                    <li class="elem">
                        <span id="oreder">05.</span>
                        <span id="menu">&nbsp;INSTRUCTORS</span>
                    </li>
                    <li class="elem">
                        <span id="oreder">06.</span>
                        <span id="menu">&nbsp;GALLERY</span>
                    </li>
                </ul>
            </div>
        </div>
    </div>

    <header class="header">
        <div class="menu">
                <div class="menu__logo">
                    <svg width="112" height="106" viewBox="0 0 559 530" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M319 0L558.023 414H79.977L319 0Z" fill="#FBF0F0"/>
                        <path d="M217 40L433.506 415H0.493652L217 40Z" fill="#DFD3D3"/>
                        <path d="M88.3799 513.7V528H28.7599V451H86.9499V465.3H46.4699V482.02H82.2199V495.88H46.4699V513.7H88.3799ZM175.514 451L142.184 528H124.584L91.3645 451H110.614L134.044 506L157.804 451H175.514ZM241.563 513.7V528H181.943V451H240.133V465.3H199.653V482.02H235.403V495.88H199.653V513.7H241.563ZM304.802 528L289.952 506.55H289.072H273.562V528H255.742V451H289.072C295.892 451 301.796 452.137 306.782 454.41C311.842 456.683 315.729 459.91 318.442 464.09C321.156 468.27 322.512 473.22 322.512 478.94C322.512 484.66 321.119 489.61 318.332 493.79C315.619 497.897 311.732 501.05 306.672 503.25L323.942 528H304.802ZM304.472 478.94C304.472 474.613 303.079 471.313 300.292 469.04C297.506 466.693 293.436 465.52 288.082 465.52H273.562V492.36H288.082C293.436 492.36 297.506 491.187 300.292 488.84C303.079 486.493 304.472 483.193 304.472 478.94ZM396.251 513.7V528H336.631V451H394.821V465.3H354.341V482.02H390.091V495.88H354.341V513.7H396.251ZM435.73 529.32C429.643 529.32 423.74 528.513 418.02 526.9C412.373 525.213 407.826 523.05 404.38 520.41L410.43 506.99C413.73 509.41 417.653 511.353 422.2 512.82C426.746 514.287 431.293 515.02 435.84 515.02C440.9 515.02 444.64 514.287 447.06 512.82C449.48 511.28 450.69 509.263 450.69 506.77C450.69 504.937 449.956 503.433 448.49 502.26C447.096 501.013 445.263 500.023 442.99 499.29C440.79 498.557 437.783 497.75 433.97 496.87C428.103 495.477 423.3 494.083 419.56 492.69C415.82 491.297 412.593 489.06 409.88 485.98C407.24 482.9 405.92 478.793 405.92 473.66C405.92 469.187 407.13 465.153 409.55 461.56C411.97 457.893 415.6 454.997 420.44 452.87C425.353 450.743 431.33 449.68 438.37 449.68C443.283 449.68 448.086 450.267 452.78 451.44C457.473 452.613 461.58 454.3 465.1 456.5L459.6 470.03C452.486 465.997 445.373 463.98 438.26 463.98C433.273 463.98 429.57 464.787 427.15 466.4C424.803 468.013 423.63 470.14 423.63 472.78C423.63 475.42 424.986 477.4 427.7 478.72C430.486 479.967 434.703 481.213 440.35 482.46C446.216 483.853 451.02 485.247 454.76 486.64C458.5 488.033 461.69 490.233 464.33 493.24C467.043 496.247 468.4 500.317 468.4 505.45C468.4 509.85 467.153 513.883 464.66 517.55C462.24 521.143 458.573 524.003 453.66 526.13C448.746 528.257 442.77 529.32 435.73 529.32ZM495.452 465.52H470.812V451H537.912V465.52H513.272V528H495.452V465.52Z" fill="white"/>
                        </svg>
                        
                </div>
        </div>

        <div class="content">
            <div class="content__title">
                <h2 class="content__article"v>
                    DISCOVER EVEREST WITH US
                </h2>
                <p class="content__text">
                    New experience
                </p>
                <div class="btn btn_white">LEAVE A REQUEST</div>
            </div>
        </div>
    </header>


    <section class="section_padding about_us">
        <div class="wrap">
            <div class="content_about">
                <img src="<?php bloginfo('template_directory')?>/img/about_us.jpg" alt="">
                <div class="about_text">
                <?php the_post(); ?>
                <?php the_content(); ?>
                </div>
            </div>
        </div>
    </section>

    <section class="section_padding about_trip">
        <div class="wrap">
            <div class="content_trip">
                <h2>About trip</h2>
                <p>
                    Climbing Everest 8848 m was first carried out from Nepal back in 1953 by Sir Edmund Hillary and Sherpa Tenzing Norgay. It was truly an outstanding act on a global scale.
                    <br>
                    <br>
                    Since then, a lot has changed, new technologies, skills and knowledge have made climbing Mount Everest more accessible and safe. 5351 people from all over the world have already 
                    climbed to the top (as of 2017) and about 600 more people climb every year in a successful season (half of them are Sherpas).
                    <br>
                    <br>
                    Climbing Mount Everest is an expensive and extremely difficult task, only a few can do it.
                    Everest, with sufficient preparation, can be your first summit. But we still recommend going down the eight-thousanders 
                    below in order to prepare for the highest peak in the world. Among other eight-thousanders, one can consider Cho-Oyu (8188), Lhotse (8516), Makalu (8481), Manaslu (8156).</p>
            </div>
        </div>
    </section>

    <section class="section_padding equipment_required">
        <div class="wrap">
            <div class="content_equipment">
                <h2 class="equipment_title">Equipment required</h2>
                <div class="equipment_box">
                    <h2>The main</h2>
                    <p>Warm sleeping bag. Comfort temperature -25 - 40.<br>
                        Assault backpack for 45-55 liters.<br>
                        Good trekking poles.</p>
                </div>
                <div class="equipment_box">
                    <h2>Shoes</h2>
                    <p>High altitude boots for climbing 8000.<br>
                        Trekking boots - semi-high, hard, well worn.<br>
                        Trekking sandals, crocs - for light trails and rest in the camp</p>
                </div>
                <div class="equipment_box">
                    <h2>Special</h2>
                    <p>Any helmet will do, the main thing is that it fits well.<br>
                        Carabiners - 4 pcs with a clutch.<br>
                        Trigger device<br>
                        Good ice ax or ice tool<br>
                        The cats are 12-tooth steel.</p>
                </div>
                <div class="equipment_box">
                    <h2>Clothing</h2>
                    <p>Warm hat<br>
                        Balaclava<br>
                        Fleece gloves<br>
                        Down jacket type "Parka 8000"</p>
                </div>
            </div>
        </div>
    </section>

    <section class="section_padding questions">
        <div class="wrap">
            <div class="content_questions">
                <h2 class="questions_title">Questions</h2>
                <div class="questions_box">
                    <h2>Will it be hard for me to walk? What does it depend on?</h2>
                    <p>It depends, first of all, on your physical fitness and individual characteristics of 
                        the body. In the second and far from the last place-from the moral mood. For example, 
                        people go to Elbrus not with their feet, 
                        but with willpower. Gender or age does not really matter.</p>
                </div>
                <div class="questions_box">
                    <h2>What kind of people go hiking?</h2>
                    <p>The vast majority of our participants are young people aged 20-35. But anyone can 
                        go on a hike with us, 
                        there would be a desire!</p>
                </div>
                <div class="questions_box">
                    <h2>And if I get sick / fall-get hurt / can't go any further?</h2>
                    <p>All our instructors are able to provide first aid. In addition, there is always a f
                        irst aid kit on the route — this is a rather large bag. If there is a serious illness 
                        or injury-together with one of the instructors, you will be sent to the nearest locality 
                        where you can get medical help. In emergency cases, you can call 
                        a helicopter of the Ministry of Emergency Situations.</p>       
                </div>
                <div class="questions_box">
                    <h2>What time will I have to get up?</h2>
                    <p>It depends a lot on the type of hike, of course. On average: on duty at 7 am, the rest - 
                        at 8. If the day is not heavy and the transition is not long, then you can sleep longer. 
                        And there are also diaries — special days when we camp on the spot and do not go anywhere. 
                        You can do any of your own things, including taking a nap until lunch (if you are not on duty, 
                        of course). But on the 
                        contrary, earlier rises are possible, if necessary.</p>
                </div>
                <div class="questions_box">
                    <h2>Can I bring a guitar / accordion / balalaika / flute / harmonica / harp?</h2>
                    <p>What you need for a hike is wonderful evenings around the campfire with songs. 
                        herefore, take your musical instrument with you, if you are not too lazy to drag 
                        it. If you play well, and even sing-popularity and attention are guaranteed. But
                         be sure to tell the instructor about your intentions BEFORE the hike, 
                        so that there are no three guitars in the hike by chance!   </p>        
                </div>
                <div class="questions_box">
                    <h2>Is it possible to lose weight on a hike?</h2>
                    <p>Theoretically, it is possible, but you can also add a couple of kilograms on the contrary. 
                        And you can also gain muscle mass — it happens in different ways! This option, by the way, 
                        is the most likely, because in the campaign we are active and get a much greater physical 
                        load than at home and in the office. It turns out that every day in an adventure is like going 
                        to the gym, 
                        plus, also eating according to a schedule.</p>
                </div>
            </div>
        </div>
    </section>

    <section class="section_padding instructors">
        <div class="content_instructors">
            <h2 class="instructors_title">Instructors</h2>
            <p class="instructors_description">People who will discover Everest for you</p>
        </div>
        <div class="slider">
            <div class="slider__item">
                <img src="<?php bloginfo('template_directory')?>/img/Instructor_1.jpg" alt="">
                <p>Опыт в горах: 15</p>
                <p class="Name">Максим Абрамов</p>
            </div>

            <div class="slider__item">
                <img src="<?php bloginfo('template_directory')?>/img/Instructor_2.jpg" alt="">
                <p>Опыт в горах: 15</p>
                <p class="Name">Максим Абрамов</p>
            </div>

            <div class="slider__item">
                <img src="<?php bloginfo('template_directory')?>/img/Instructor_3.jpg" alt="">
                <p>Опыт в горах: 15</p>
                <p class="Name">Максим Абрамов</p>
            </div>

            <div class="slider__item">
                <img src="<?php bloginfo('template_directory')?>/img/Instructor_4.jpg" alt="">
                <p>Опыт в горах: 15</p>
                <p class="Name">Максим Абрамов</p>
            </div>

            <div class="slider__item">
                <img src="<?php bloginfo('template_directory')?>/img/Instructor_5.jpg" alt="">

                    <p>Опыт в горах: 15</p>
                    <p class="Name">Максим Абрамов</p>

            </div>
        </div>
    </section>

    <section class="section_padding gallery">
        <h2 class="instructors_title">Gallery</h2>
        <div class="slider">
            <div class="slider__item">
                <img src="<?php bloginfo('template_directory')?>/img/gallery/slide_1.jpg" alt="">
            </div>

            <div class="slider__item">
                <img src="<?php bloginfo('template_directory')?>/img/gallery/slide_2.jpg" alt="">
            </div>

            <div class="slider__item">
                <img src="<?php bloginfo('template_directory')?>/img/gallery/slide_3.jpg" alt="">
            </div>

            <div class="slider__item">
                <img src="<?php bloginfo('template_directory')?>/img/gallery/slide_4.jpg" alt="">
            </div>

            <div class="slider__item">
                <img src="<?php bloginfo('template_directory')?>/img/gallery/slide_5.jpg" alt="">
            </div>
        </div>
    </section>

    <section class="section_padding contact_us">
        <div class="wrap">
            <h2>Contact us</h2>
        <div class="contact_us__content">
            <form action="" >
                <input id="GET-name" type="text" name="name" placeholder="Name" size=35>
                <input id="GET-mail" type="text" name="mail" placeholder="E-mail" size=35>
                <input id="GET-mobile" type="text" name="mobile" placeholder="Mobile number" size=35>
                <input id="Leave" type="submit" value="LEAVE A REQUEST">
            </form>
            <img src="<?php bloginfo('template_directory')?>/img/contact_us.jpg" alt="">
        </div>
        </div>
    </section>

    <section class="section_padding our_data">
        <div class="wrap">
            <h2>Our data</h2>
        <div class="our_data__content">
            <div class="text">
                <h3 class="number">+7(908) 412-45-96</h3>
                <h3 class="number">+7(908) 512-12-45</h3>
                <h3>@everest_team</h3>
            </div>
            <div class="content_map">
                <script type="text/javascript" charset="utf-8" async src="https://api-maps.yandex.ru/services/constructor/1.0/js/?um=constructor%3Ad2b36153fc16b5b2b042abf2e71d2d25f67f9d53498d97664725ee0ecfdb7db1&amp;width=100%&amp;height=603&amp;lang=ru_RU&amp;scroll=true"></script>
            </div>
        </div>
        </div>
    </section>

    <footer>
        <div class="footer__logo">
            <a href="#">EVEREST</a>
        </div>
        <p>© 2021 EVEREST</p>
    </footer>

    
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="<?php bloginfo('template_directory')?>/js/slick.min.js"></script>
    <script src="<?php bloginfo('template_directory')?>/js/code.js"></script>
</body>
</html>